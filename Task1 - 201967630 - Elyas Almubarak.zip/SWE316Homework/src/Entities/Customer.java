package Entities;

public class Customer {
	private String customer;
	
	public Customer(String customer) {
		this.customer = customer;
	}
	
	public String getCustomer() {
		return customer;
	}
}
