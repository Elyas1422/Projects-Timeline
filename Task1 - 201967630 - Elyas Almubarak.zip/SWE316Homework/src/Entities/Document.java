package Entities;

public class Document {
	private int documentNumber;
	
	public Document(int documentNumber) {
		this.documentNumber = documentNumber;
	}
	
	public int getDocumentNumber() {
		return documentNumber;
	}
}
