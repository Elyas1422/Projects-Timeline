module SWE316Homework {
	exports Application;

	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
    requires org.apache.poi.poi;
}